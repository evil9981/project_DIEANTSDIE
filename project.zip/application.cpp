//==============================================================================
/*
    \author    Your Name
*/
//==============================================================================

//------------------------------------------------------------------------------
#include "chai3d.h"
#include "minion.h"
//------------------------------------------------------------------------------
using namespace chai3d;
using namespace std;
//------------------------------------------------------------------------------
#ifndef MACOSX
#include "GL/glut.h"
#else
#include "GLUT/glut.h"
#endif
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// GENERAL SETTINGS
//------------------------------------------------------------------------------

// stereo Mode
/*
    C_STEREO_DISABLED:            Stereo is disabled 
    C_STEREO_ACTIVE:              Active stereo for OpenGL NVDIA QUADRO cards
    C_STEREO_PASSIVE_LEFT_RIGHT:  Passive stereo where L/R images are rendered next to each other
    C_STEREO_PASSIVE_TOP_BOTTOM:  Passive stereo where L/R images are rendered above each other
*/
cStereoMode stereoMode = C_STEREO_DISABLED;

// fullscreen mode
bool fullscreen = false;

// mirrored display
bool mirroredDisplay = false;


//------------------------------------------------------------------------------
// DECLARED VARIABLES
//------------------------------------------------------------------------------

// a world that contains all objects of the virtual environment
cWorld* world;

// a camera to render the world in the window display
cCamera* camera;

// a light source to illuminate the objects in the world
cDirectionalLight *light;

// a haptic device handler
cHapticDeviceHandler* handler;

// a pointer to the current haptic device
cGenericHapticDevicePtr hapticDevice;

// a label to display the rate [Hz] at which the simulation is running
cLabel* labelHapticRate;

// a small sphere (cursor) representing the haptic device 
//cShapeSphere* cursor;

cToolCursor* tool;

// flag to indicate if the haptic simulation currently running
bool simulationRunning = false;

// flag to indicate if the haptic simulation has terminated
bool simulationFinished = false;

// frequency counter to measure the simulation haptic rate
cFrequencyCounter frequencyCounter;

// information about computer screen and GLUT display window
int screenW;
int screenH;
int windowW;
int windowH;
int windowPosX;
int windowPosY;

// testing floor
//cShapeBox* testFloor;
cMultiMesh* cake;
cMesh* table;
double toolRadius = 0.0025;

cShapeCylinder* fakeSpawns[8];
minion* fakeAnts[16];
double previousT = 0;
double previousT2 = 0;
double spawnRadius = 0.05;


// Justin's part
//------------------------------------------------------------------------------
cMultiMesh *monkey;
cMultiMesh *monkey2;
int hitpoints = 3;
bool touched = false;
cGenericObject* object;
double offset = 0.0;

struct unit
{
	int speed;
	int hitpoints;
	cMultiMesh * mesh;
	string type;
};

vector<unit*> units;
//unit* minions[16];
//double toolRadius = 0.002;
int money = 0;

int pushed = 0;
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// DECLARED FUNCTIONS
//------------------------------------------------------------------------------

// callback when the window display is resized
void resizeWindow(int w, int h);

// callback when a key is pressed
void keySelect(unsigned char key, int x, int y);

// callback to render graphic scene
void updateGraphics(void);

// callback of GLUT timer
void graphicsTimer(int data);

// function that closes the application
void close(void);

// main haptics simulation loop
void updateHaptics(void);


//==============================================================================
/*
    TEMPLATE:    application.cpp

    Description of your application.
*/
//==============================================================================

int main(int argc, char* argv[])
{
    //--------------------------------------------------------------------------
    // INITIALIZATION
    //--------------------------------------------------------------------------

    cout << endl;
    cout << "-----------------------------------" << endl;
    cout << "CHAI3D" << endl;
    cout << "-----------------------------------" << endl << endl << endl;
    cout << "Keyboard Options:" << endl << endl;
    cout << "[f] - Enable/Disable full screen mode" << endl;
    cout << "[m] - Enable/Disable vertical mirroring" << endl;
    cout << "[x] - Exit application" << endl;
    cout << endl << endl;


    //--------------------------------------------------------------------------
    // OPENGL - WINDOW DISPLAY
    //--------------------------------------------------------------------------

    // initialize GLUT
    glutInit(&argc, argv);

    // retrieve  resolution of computer display and position window accordingly
    screenW = glutGet(GLUT_SCREEN_WIDTH);
    screenH = glutGet(GLUT_SCREEN_HEIGHT);
    windowW = (int)(0.8 * screenH);
    windowH = (int)(0.5 * screenH);
    windowPosY = (screenH - windowH) / 2;
    windowPosX = windowPosY; 

    // initialize the OpenGL GLUT window
    glutInitWindowPosition(windowPosX, windowPosY);
    glutInitWindowSize(windowW, windowH);

    if (stereoMode == C_STEREO_ACTIVE)
        glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE | GLUT_STEREO);
    else
        glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);

    // create display context and initialize GLEW library
    glutCreateWindow(argv[0]);

#ifdef GLEW_VERSION
    // initialize GLEW
    glewInit();
#endif

    // setup GLUT options
    glutDisplayFunc(updateGraphics);
    glutKeyboardFunc(keySelect);
    glutReshapeFunc(resizeWindow);
    glutSetWindowTitle("CHAI3D");

    // set fullscreen mode
    if (fullscreen)
    {
        glutFullScreen();
    }


    //--------------------------------------------------------------------------
    // WORLD - CAMERA - LIGHTING
    //--------------------------------------------------------------------------

    // create a new world.
    world = new cWorld();

    // set the background color of the environment
    world->m_backgroundColor.setWhite();

    // create a camera and insert it into the virtual world
    camera = new cCamera(world);
    world->addChild(camera);

    // position and orient the camera
    camera->set( cVector3d (0.1, 0.0, 0.05),    // camera position (eye)
                 cVector3d (0.0, 0.0, 0.0),    // look at position (target)
                 cVector3d (0.0, 0.0, 1.0));   // direction of the (up) vector

    // set the near and far clipping planes of the camera
    camera->setClippingPlanes(0.01, 10.0);

    // set stereo mode
    camera->setStereoMode(stereoMode);

    // set stereo eye separation and focal length (applies only if stereo is enabled)
    camera->setStereoEyeSeparation(0.01);
    camera->setStereoFocalLength(0.5);

    // set vertical mirrored display mode
    camera->setMirrorVertical(mirroredDisplay);

    // create a directional light source
    light = new cDirectionalLight(world);

    // insert light source inside world
    world->addChild(light);

    // enable light source
    light->setEnabled(true);

    // define direction of light beam
    light->setDir(-1.0, 0.0, 0.0); 

	

    //--------------------------------------------------------------------------
    // HAPTIC DEVICE / TOOLS
    //--------------------------------------------------------------------------

    // create a haptic device handler
    handler = new cHapticDeviceHandler();

    // get a handle to the first haptic device
    handler->getDevice(hapticDevice, 0);

    // open a connection to haptic device
    hapticDevice->open();

    // calibrate device (if necessary)
    hapticDevice->calibrate();

    // retrieve information about the current haptic device
    cHapticDeviceInfo info = hapticDevice->getSpecifications();

	// create a 3D tool and add it to the world
	tool = new cToolCursor(world);
	camera->addChild(tool);
	tool->enableDynamicObjects(true);

	// position tool in respect to camera
	tool->setLocalPos(0.0, 0.0, 0.0);

	// connect the haptic device to the tool
	tool->setHapticDevice(hapticDevice);
	
	// define a radius for the tool
	tool->setRadius(toolRadius);

	// map the physical workspace of the haptic device to a larger virtual workspace.
	tool->setWorkspaceRadius(0.2);

	// start the haptic tool
	tool->start();

    // if the device has a gripper, enable the gripper to simulate a user switch
    hapticDevice->setEnableGripperUserSwitch(true);


	//--------------------------------------------------------------------------
	// CREATE OBJECTS
	//--------------------------------------------------------------------------

	// read the scale factor between the physical workspace of the haptic
	// device and the virtual workspace defined for the tool
	double workspaceScaleFactor = tool->getWorkspaceScaleFactor();

	// properties
	double maxStiffness = info.m_maxLinearStiffness / workspaceScaleFactor;


	table = new cMesh();
	cCreatePlane(table, 0.3, 0.3);
	table->createAABBCollisionDetector(toolRadius);
	world->addChild(table);
	table->m_texture = cTexture2d::create();
	table->m_texture->loadFromFile("woodTexture.jpg");
	table->setUseTexture(true);
	table->m_material->setWhite();

	cNormalMapPtr normalTable = cNormalMap::create();
	normalTable->createMap(table->m_texture);
	table->m_normalMap = normalTable;
	table->m_material->setStiffness(0.6 * maxStiffness);
	table->m_material->setStaticFriction(0.62);
	table->m_material->setDynamicFriction(0.48);

	cake = new cMultiMesh;
	cake->loadFromFile("UglyCake.obj");
	cake->scale(0.015);
	world->addChild(cake);
	
	cake->createAABBCollisionDetector(toolRadius);
	cake->setStiffness(0.3 * maxStiffness);


	// spawn point
	for (int i = 0; i < 8; i++){
		cShapeCylinder* spawn = new cShapeCylinder(0.003, 0.003, 0.0001);
		double degToRad = (double)(i * 45) / 180 * C_PI;
		spawn->m_material->setBlack();
		spawn->setLocalPos(cos(degToRad)*spawnRadius, sin(degToRad)*spawnRadius, 0);
		fakeSpawns[i] = spawn;
		world->addChild(spawn);
	}

	// creating ants
	//for (int i = 0; i < 16; i++){
	//	minion* ant = new minion(0.002);
	//	ant->health = 10;
	//	ant->speed = 0.0003;
	//	double degToRad = (double)(i * 45) / 180 * C_PI;
	//	ant->m_material->setRedCrimson();
	//	ant->setLocalPos(cos(degToRad)*spawnRadius, sin(degToRad)*spawnRadius, 0.001);
	//	fakeAnts[i] = ant;
	//	world->addChild(ant);
	//}

	//for (int i = 0; i < 16; i++){
		monkey = new cMultiMesh();
		monkey->loadFromFile("Ant.obj");
		unit *enemy = new unit;
		enemy->mesh = monkey;
		enemy->hitpoints = 5;
		enemy->speed = 0.0003;
		enemy->mesh->scale(0.001);
		enemy->type = "normal";
		enemy->mesh->createAABBCollisionDetector(toolRadius);
		enemy->mesh->setStiffness(500, true);
		enemy->mesh->computeBoundaryBox(true);
		double degToRad = (double)(0 * 45) / 180 * C_PI;

		//switch (i){
		//case 0:
		//	enemy->mesh->m_material->setBlack();
		//case 1:
		//	enemy->mesh->m_material->setBlue();
		//case 2:
		//	enemy->mesh->m_material->setRed();
		//case 3:
		//	enemy->mesh->m_material->setYellow();
		//case 4:
		//	enemy->mesh->m_material->setPink();
		//case 5:
		//	enemy->mesh->m_material->setBrown();
		//case 6:
		//	enemy->mesh->m_material->setPurple();
		//case 7:
		//	enemy->mesh->m_material->setBlueAqua();
		//}	
		
		

		enemy->mesh->setLocalPos(cos(degToRad)*spawnRadius, sin(degToRad)*spawnRadius, 0.001);
		units.push_back(enemy);
		world->addChild(units[0]->mesh);

	//}

	// Justin's part
	//--------------------------------------------------------------------------
	//monkey = new cMultiMesh();
	//monkey2 = new cMultiMesh();
	////units = new vector<unit>;
	//unit *first = new unit;
	//first->mesh = monkey;
	//first->hitpoints = 5;
	//first->speed = 0.0003;
	//first->type = "normal";

	//unit *second = new unit;
	//second->mesh = monkey2;
	//second->speed = 0.0003;
	//second->hitpoints = 5;


	//units.push_back(first);

	//first = new unit;
	//monkey = new cMultiMesh();
	//first->mesh = monkey;
	//first->hitpoints = 5;
	//first->type = "normal";
	//units.push_back(first);

	//world->addChild(units[0]->mesh);

	//units[0]->mesh->computeBoundaryBox(true);

	//units[0]->mesh->loadFromFile("monkey.obj");
	////units[0]->mesh->translate(-0.025, -0.025, 0);
	//units[0]->mesh->scale(0.01);



	//units[0]->mesh->createAABBCollisionDetector(toolRadius);
	//units[0]->mesh->setStiffness(500, true);

	//units[0]->mesh->setFriction(0.1, 0.2, true);

	////world->addChild(units[0]->mesh);


	//units[1]->mesh->loadFromFile("monkey.obj");
	//units[1]->mesh->computeBoundaryBox(true);
	//units[1]->mesh->translate(0.025, 0.025, 0);
	//units[1]->mesh->scale(0.01);
	//units[1]->mesh->createAABBCollisionDetector(toolRadius);
	//units[1]->mesh->setStiffness(500);

	//world->addChild(units[1]->mesh);
	//--------------------------------------------------------------------------


    //--------------------------------------------------------------------------
    // WIDGETS
    //--------------------------------------------------------------------------

    // create a font
    cFont *font = NEW_CFONTCALIBRI20();
    
    // create a label to display the haptic rate of the simulation
    labelHapticRate = new cLabel(font);
    labelHapticRate->m_fontColor.setBlack();
    camera->m_frontLayer->addChild(labelHapticRate);


    //--------------------------------------------------------------------------
    // START SIMULATION
    //--------------------------------------------------------------------------

    // create a thread which starts the main haptics rendering loop
    cThread* hapticsThread = new cThread();
    hapticsThread->start(updateHaptics, CTHREAD_PRIORITY_HAPTICS);

    // setup callback when application exits
    atexit(close);

    // start the main graphics rendering loop
    glutTimerFunc(50, graphicsTimer, 0);
    glutMainLoop();

    // exit
    return (0);
}

//------------------------------------------------------------------------------

void resizeWindow(int w, int h)
{
    windowW = w;
    windowH = h;
}

//------------------------------------------------------------------------------

void keySelect(unsigned char key, int x, int y)
{
    // option ESC: exit
    if ((key == 27) || (key == 'x'))
    {
        close();
        exit(0);
    }

    // option f: toggle fullscreen
    if (key == 'f')
    {
        if (fullscreen)
        {
            windowPosX = glutGet(GLUT_INIT_WINDOW_X);
            windowPosY = glutGet(GLUT_INIT_WINDOW_Y);
            windowW = glutGet(GLUT_INIT_WINDOW_WIDTH);
            windowH = glutGet(GLUT_INIT_WINDOW_HEIGHT);
            glutPositionWindow(windowPosX, windowPosY);
            glutReshapeWindow(windowW, windowH);
            fullscreen = false;
        }
        else
        {
            glutFullScreen();
            fullscreen = true;
        }
    }

    // option m: toggle vertical mirroring
    if (key == 'm')
    {
        mirroredDisplay = !mirroredDisplay;
        camera->setMirrorVertical(mirroredDisplay);
    }
}

//------------------------------------------------------------------------------

void close(void)
{
    // stop the simulation
    simulationRunning = false;

    // wait for graphics and haptics loops to terminate
    while (!simulationFinished) { cSleepMs(100); }

    // close haptic device
    hapticDevice->close();
}

//------------------------------------------------------------------------------

void graphicsTimer(int data)
{
    if (simulationRunning)
    {
        glutPostRedisplay();
    }

    glutTimerFunc(50, graphicsTimer, 0);
}

//------------------------------------------------------------------------------

void updateGraphics(void)
{
    /////////////////////////////////////////////////////////////////////
    // UPDATE WIDGETS
    /////////////////////////////////////////////////////////////////////

    // display haptic rate data
    labelHapticRate->setText(cStr(frequencyCounter.getFrequency(), 0) + " Hz");

    // update position of label
    labelHapticRate->setLocalPos((int)(0.5 * (windowW - labelHapticRate->getWidth())), 15);


    /////////////////////////////////////////////////////////////////////
    // RENDER SCENE
    /////////////////////////////////////////////////////////////////////

    // update shadow maps (if any)
    world->updateShadowMaps(false, mirroredDisplay);

    // render world
    camera->renderView(windowW, windowH);

    // swap buffers
    glutSwapBuffers();

    // wait until all GL commands are completed
    glFinish();

    // check for any OpenGL errors
    GLenum err;
    err = glGetError();
    if (err != GL_NO_ERROR) cout << "Error:  %s\n" << gluErrorString(err);
}


// actually it moves the ants
void calcAntPos(unit* object){
	
	double stepsize = object->speed;
	cVector3d antPos = object->mesh->getLocalPos();

	double distance = sqrt(pow(antPos.x(), 2) + pow(antPos.y(), 2));
	double angle = atan(antPos.x() / antPos.y());
	double xsign = antPos.x() / abs(antPos.x());
	double ysign = antPos.y() / abs(antPos.y());


	if (antPos.y() < 0){
		if (antPos.x() >= 0){
			object->mesh->setLocalPos((distance - stepsize)*sin(angle)* ysign, (distance - stepsize)*cos(angle) * ysign, 0.001);
		}
		else{
			object->mesh->setLocalPos((distance - stepsize)*sin(angle)*xsign, (distance - stepsize)*cos(angle) * ysign, 0.001);
		}
	}
	else{
		object->mesh->setLocalPos((distance - stepsize)*sin(angle), (distance - stepsize)*cos(angle), 0.001);
	}
	
}


//------------------------------------------------------------------------------

void updateHaptics(void)
{
    // initialize frequency counter
    frequencyCounter.reset();

    // simulation in now running
    simulationRunning  = true;
    simulationFinished = false;

	cPrecisionClock timer;
	timer.start();

    // main haptic simulation loop
    while(simulationRunning)
    {



		// timer
		double t = timer.getCurrentTimeSeconds();
		

		//if ((t - previousT) > 0.1){
		//	previousT = t;
		//	for (int i = 0; i < 8; i++){
		//		calcAntPos(units[i]);
		//	}

		//	if (t > 5.5){
		//		for (int i = 8; i < 16; i++){
		//			calcAntPos(units[i]);
		//		}
		//	}
		//}

		if ((t - previousT) > 0.1){
			previousT = t;
			calcAntPos(units[0]);
		}


        /////////////////////////////////////////////////////////////////////
        // READ HAPTIC DEVICE
        /////////////////////////////////////////////////////////////////////

        // read position 
        cVector3d position;
        hapticDevice->getPosition(position);

        // read orientation 
        cMatrix3d rotation;
        hapticDevice->getRotation(rotation);

        // read user-switch status (button 0)
        bool button = false;
        hapticDevice->getUserSwitch(0, button);


        /////////////////////////////////////////////////////////////////////
        // UPDATE 3D TOOLS
        /////////////////////////////////////////////////////////////////////

		world->computeGlobalPositions(true);
		
		// update position and orientation of tool
		tool->updateFromDevice();

		// compute interaction forces
		tool->computeInteractionForces();

		// send forces to haptic device
		tool->applyToDevice();

		// Justin's code
		//-------------------------------------------------------------------
		cHapticPoint* interactionPoint = tool->getHapticPoint(0);

		int x;

		// check primary contact point if available
		if (interactionPoint->getNumCollisionEvents() > 0 && touched == false)
		{
			cCollisionEvent* collisionEvent = interactionPoint->getCollisionEvent(0);

			// given the mesh object we may be touching, we search for its owner which
			// could be the mesh itself or a multi-mesh object. Once the owner found, we
			// look for the parent that will point to the ODE object itself.
			cGenericObject* object = collisionEvent->m_object->getOwner();
			//cODEGenericBody* ODEobject = dynamic_cast<cODEGenericBody*>(object);
			cMultiMesh* multiObject = dynamic_cast<cMultiMesh*>(object);

			for (int i = 0; i < units.size(); i++)
			{
				if (units[i]->mesh == multiObject)
				{
					x = i;
					cVector3d centre = units[x]->mesh->getLocalPos();

					if (position.z() > units[x]->mesh->getLocalPos().z() + offset)
					{
						units[x]->hitpoints--;


						touched = true;
						/*if (units[x]->hitpoints <= 0)
						{*/
							units[x]->mesh->setEnabled(0);
							//world->removeChild(object);
							touched = false;
							if (units[x]->type == "normal")
								money++;
							else if (units[x]->type == "quick")
								money = money + 2;
						//}
					}
				}
			}

			
			
		}

		else if (interactionPoint->getNumCollisionEvents() <= 0 && touched == true)
		{
			touched = false;
			//world->removeChild(monkey);
		}

		if (button == TRUE && pushed == 0)
			pushed = 1;

		if (pushed == 1)
		{
			unit *first = new unit;
			monkey = new cMultiMesh();
			first->mesh = monkey;
			first->hitpoints = 5;

			units.push_back(first);

			world->addChild(units[units.size() - 1]->mesh);

			units[units.size() - 1]->mesh->computeBoundaryBox(true);

			units[units.size() - 1]->mesh->loadFromFile("monkey.obj");
			units[units.size() - 1]->mesh->setLocalPos(position);
			units[units.size() - 1]->mesh->scale(0.01);
			first->type = "quick";



			units[units.size() - 1]->mesh->createAABBCollisionDetector(toolRadius);
			units[units.size() - 1]->mesh->setStiffness(500, true);

			units[units.size() - 1]->mesh->setFriction(0.1, 0.2, true);
			pushed = 2;

		}

		if (button == FALSE && pushed == 2)
			pushed = 0;

		//-------------------------------------------------------------------


        /////////////////////////////////////////////////////////////////////
        // COMPUTE FORCES
        /////////////////////////////////////////////////////////////////////

        cVector3d force(0, 0, 0);
        cVector3d torque(0, 0, 0);
        double gripperForce = 0.0;


        /////////////////////////////////////////////////////////////////////
        // APPLY FORCES
        /////////////////////////////////////////////////////////////////////

        // send computed force, torque, and gripper force to haptic device
        //hapticDevice->setForceAndTorqueAndGripperForce(force, torque, gripperForce);

        // update frequency counter
        frequencyCounter.signal(1);
    }
    
    // exit haptics thread
    simulationFinished = true;
}

//------------------------------------------------------------------------------
